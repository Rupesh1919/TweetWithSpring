package com.tweetapp.ws.services;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.tweetapp.ws.shared.Dto.UserDto;

public interface UserService extends UserDetailsService {
	UserDto createUser(UserDto userDto);

}
