package com.tweetapp.ws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TweetAppWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
